$('#invio').on('click' , function(){
    this.preventDefault();
    history.back();
})