function ringraziamenti() {
window.alert('Questo sito è stato realizzato da 3 ragazzi. Lascia un feedback e aiutaci a migliorarlo :) NB è consigliata la visione da computer');
}
window.addEventListener('load' , ringraziamenti ,false) ;